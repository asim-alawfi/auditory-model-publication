%% Called when unknown bifurcation is encountered
function [bifdummy,bifdummylow,branch,ind]=nmfm_dummy(funcs,branch,inds,varargin) %#ok<INUSL>
%
% $Id: nmfm_dummy.m 309 2018-10-28 19:02:42Z jansieber $
% 
bifdummy=[];
bifdummylow=[];
ind=inds(1);
end